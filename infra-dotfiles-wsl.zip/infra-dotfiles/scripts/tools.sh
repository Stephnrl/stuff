#!/usr/bin/env bash
set -Eeuo pipefail
export DEBIAN_FRONTEND=noninteractive
sudo apt-get update
sudo apt-get install -y build-essential curl wget file git tmux ca-certificates pkg-config libssl-dev unzip python3 python3-pip
# Homebrew official installer; deliberately reviewed/opt-in and not run with sudo.
if [ ! -x /home/linuxbrew/.linuxbrew/bin/brew ]; then
  echo 'Homebrew missing. This will download the official installer from Homebrew/install.'
  echo 'Review https://github.com/Homebrew/install before continuing.'
  if [ ! -t 0 ]; then echo 'Interactive terminal required for Homebrew approval.' >&2; exit 1; fi
  read -r -p 'Download and run Homebrew installer? [y/N] ' answer
  case "$answer" in [yY]|[yY][eE][sS]) ;; *) echo 'Skipping Homebrew and brew packages.'; exit 0;; esac
  tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
  curl --fail --location --silent --show-error 'https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh' -o "$tmp"
  /bin/bash "$tmp"
  rm -f "$tmp"; trap - EXIT
fi
eval "$(/home/linuxbrew/.linuxbrew/bin/brew shellenv)"
brew install gh azure-cli awscli kubernetes-cli helm || { echo 'Some brew packages failed; inspect network/proxy trust.' >&2; exit 1; }
brew install warrensbox/tap/tfswitch
# Ubuntu packages rustup; rustup controls compiler versions (not Homebrew rust).
sudo apt-get install -y rustup
rustup toolchain install 1.99.0 --profile default
rustup default 1.99.0
printf 'Tools installed. Authenticate cloud CLIs separately.\n'
