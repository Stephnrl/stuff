#!/usr/bin/env bash
set -Eeuo pipefail
base="${MUX_DEV_DIR:-$HOME/dev}"; mkdir -p "$base"
for name in mux.snc mux.snc-tools; do
  target="$base/$name"
  if [ -e "$target" ]; then echo "Already present: $target (no update)"; continue; fi
  git clone "git@github.com:Stephnrl/$name.git" "$target"
done
cat <<MSG
Cloned repositories only; no agent processes started.
Build mux.snc using its documented WSL installer:
  cd "$base/mux.snc" && bash scripts/install.sh --with-rust --ca /usr/local/share/ca-certificates/zscaler.crt
Only run the --ca argument if you intentionally trust that certificate.
For mux.snc-tools follow docs/installation.md and the CLI/plugin instructions in README.md.
MSG
