#!/usr/bin/env bash
set -Eeuo pipefail
command -v claude >/dev/null 2>&1 || { echo 'Claude Code CLI not installed; skipping marketplace.'; exit 0; }
echo 'Adding private marketplace; requires existing GitHub authorization.'
claude plugin marketplace add Stephnrl/mux.snc-tools
claude plugin install mux-core@mux-marketplace
