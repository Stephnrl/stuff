#!/usr/bin/env bash
set -Eeuo pipefail
ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
WITH_TOOLS=0 WITH_MUX=0 WITH_PLUGINS=0 WITH_CA=0
usage() { echo 'Usage: bash scripts/install.sh [--tools] [--mux] [--plugins] [--trust-zscaler]'; }
for arg in "$@"; do
  case "$arg" in
    --tools) WITH_TOOLS=1;;
    --mux) WITH_MUX=1;;
    --plugins) WITH_PLUGINS=1;;
    --trust-zscaler) WITH_CA=1;;
    -h|--help) usage; exit 0;;
    *) echo "Unknown option: $arg" >&2; usage; exit 2;;
  esac
done
. /etc/os-release
if [ "${ID:-}" != ubuntu ] || [ "${VERSION_ID:-}" != 24.04 ]; then
  echo 'This installer supports Ubuntu 24.04 only.' >&2; exit 1
fi
backup_dir="$HOME/.local/state/infra-dotfiles/backups/$(date +%Y%m%d-%H%M%S)-$$"
install_link() {
  local source=$1 destination=$2
  mkdir -p "$(dirname "$destination")"
  if [ -L "$destination" ] && [ "$(readlink "$destination")" = "$source" ]; then return; fi
  if [ -e "$destination" ] || [ -L "$destination" ]; then
    mkdir -p "$backup_dir"
    mv -- "$destination" "$backup_dir/$(basename "$destination").$(date +%s%N)"
    echo "Backed up $destination under $backup_dir"
  fi
  ln -s "$source" "$destination"
}
mkdir -p "$HOME/.config/infra-dotfiles" "$HOME/.local/bin"
install_link "$ROOT/bash/bashrc" "$HOME/.config/infra-dotfiles/bashrc"
install_link "$ROOT/bash/profile" "$HOME/.config/infra-dotfiles/profile"
install_link "$ROOT/bash/prompt.sh" "$HOME/.config/infra-dotfiles/prompt.sh"
install_link "$ROOT/bash/aliases.sh" "$HOME/.config/infra-dotfiles/aliases.sh"
install_link "$ROOT/tmux/tmux.conf" "$HOME/.tmux.conf"
# Don't replace Ubuntu's default startup files; append a single managed block.
for item in '.bashrc|bashrc' '.profile|profile'; do
  dest="$HOME/${item%%|*}"; fragment="${item##*|}"
  touch "$dest"
  line="[ -f \"\$HOME/.config/infra-dotfiles/$fragment\" ] && . \"\$HOME/.config/infra-dotfiles/$fragment\""
  if ! grep -Fqx "$line" "$dest"; then
    mkdir -p "$backup_dir"; cp -p "$dest" "$backup_dir/${dest##*/}.before-edit"
    printf '\n# infra-dotfiles\n%s\n' "$line" >> "$dest"
  fi
done
if [ "$WITH_CA" -eq 1 ]; then
  cert=/usr/local/share/ca-certificates/zscaler.crt
  [ -s "$cert" ] || { echo "Missing $cert" >&2; exit 1; }
  sudo update-ca-certificates
fi
if [ "$WITH_TOOLS" -eq 1 ]; then bash "$ROOT/scripts/tools.sh"; fi
if [ "$WITH_MUX" -eq 1 ]; then bash "$ROOT/scripts/mux.sh"; fi
if [ "$WITH_PLUGINS" -eq 1 ]; then bash "$ROOT/scripts/plugins.sh"; fi
printf '\nDone. Open a new WSL session to load the profile.\n'
