# Infrastructure dotfiles for WSL Ubuntu 24.04

Minimal Bash prompt, Ctrl+A tmux, standard developer PATH, optional infrastructure CLIs, and opt-in mux repo clones.

## Installation

Clone this directory into WSL, e.g. `~/dev/infra-dotfiles` and run:

```bash
bash scripts/install.sh                   # Only Bash/tmux dotfiles, backs up originals
bash scripts/install.sh --trust-zscaler   # Opt in to OS trust update after reviewing the CA
bash scripts/install.sh --tools           # APT + Homebrew tools, prompts to install Homebrew if absent
bash scripts/install.sh --mux             # Clone both private projects via SSH
bash scripts/install.sh --plugins         # Install mux-core Claude plugin when Claude CLI is present
```

Homebrew installation prompts for explicit approval, downloads the official Homebrew installer and runs it. Inspect https://github.com/Homebrew/install first; it requires an interactive terminal. The exact requested base PATH is included, along with Cargo and local bin paths. `--tools` installs `gh`, Azure CLI, AWS CLI, `kubectl`, Helm, `tfswitch`, and the Rust 1.99.0 toolchain using rustup. Terraform itself is installed/selected separately through `tfswitch`.

## Security, corporate CA, and project boundaries

- `--trust-zscaler` runs `sudo update-ca-certificates` for the existing `/usr/local/share/ca-certificates/zscaler.crt`; verify its fingerprint and organizational provenance before opting in. Never set `GIT_SSL_NO_VERIFY` or disable TLS verification.
- OS CA trust does not guarantee every CLI's private trust store uses that bundle. Test `curl`, `git`, `gh`, `cargo`, `az`, and `aws` independently; configure corporate proxies and any custom trust requirements per vendor. Rustup downloads may require separately configured trust in constrained environments.
- No tokens, PATs, `.env` files, or cloud credentials are stored in dotfiles. Authenticate yourself with `gh auth login`, `az login`, `aws configure sso`, etc.
- `--mux` clones only, without overwriting dirty worktrees or installing SNC. Upstream mux.snc WSL install and plugin CLI installations remain their own documented, reviewed actions.
- Files already owned by the user are backed up on each changed installation. Managed dotfiles are symlinked and must remain in the cloned directory.
- Review package sources, versions, network egress, and company authorization before installing on managed endpoints.
- Custom local overrides belong in `~/.config/infra-dotfiles/local.sh` (not tracked).

## Validation

```bash
bash -n bash/* scripts/*.sh
shellcheck bash/* scripts/*.sh # if ShellCheck is installed
bash scripts/install.sh --help
rustc --version; cargo --version; gh --version; tfswitch --version
```

Keep Terraform versions per repo in `.terraform-version` where appropriate. `tfswitch` controls active Terraform binaries; avoid shadowing its selected Terraform path with a different installation.
