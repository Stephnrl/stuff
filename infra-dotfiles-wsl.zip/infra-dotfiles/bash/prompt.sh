# Keep PS1 easy to understand; no third-party theme or subprocess for the date.
# Preserve bash readline length accounting: ANSI escapes in PS1 are enclosed in \[ \].
# Git branch is dynamic via PROMPT_COMMAND rather than nested escapes in command substitution.
__infra_prompt() {
  local branch='' b='' dirty=''
  if command -v git >/dev/null 2>&1; then
    b=$(git symbolic-ref --quiet --short HEAD 2>/dev/null) || b=$(git rev-parse --short HEAD 2>/dev/null) || b=''
    if [ -n "$b" ]; then
      [ -n "$(git status --porcelain --untracked-files=no 2>/dev/null)" ] && dirty='*'
      branch=" \[\e[36m\]⎇ ${b}${dirty}\[\e[0m\]"
    fi
  fi
  PS1="\[\e[32m\]\\h\[\e[0m\] \[\e[37m\]\\w\[\e[0m\]${branch} \[\e[33m\]\\D{%Y-%m-%d %H:%M}\[\e[0m\]\\n\[\e[32m\]❯\[\e[0m\] "
}
if [ -z "${PROMPT_COMMAND:-}" ]; then PROMPT_COMMAND=__infra_prompt
else PROMPT_COMMAND="${PROMPT_COMMAND%;}; __infra_prompt"; fi
