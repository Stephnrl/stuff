alias ll='ls -alF'
alias la='ls -A'
alias gs='git status --short --branch'
alias gl='git log --oneline --decorate -12'
alias k='kubectl'
alias tf='terraform'
alias h='helm'
# Avoid aliases that hide cloud contexts or change resources automatically.
